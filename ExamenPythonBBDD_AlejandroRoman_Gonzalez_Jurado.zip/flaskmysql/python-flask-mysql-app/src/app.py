from flask import Flask, render_template, request, redirect, url_for
import os
import database as db

template_dir = os.path.dirname(os.path.abspath(os.path.dirname(__file__)))
template_dir = os.path.join(template_dir, 'src', 'templates')

app = Flask(__name__, template_folder = template_dir)

#Rutas de la aplicación
@app.route('/')
def home():
    cursor = db.database.cursor()
    #Cambiamos el nombre de la tabla al nuestro.
    cursor.execute("SELECT * FROM gonzalez")
    myresult = cursor.fetchall()
    #Convertir los datos a diccionario
    insertObject = []
    columnNames = [column[0] for column in cursor.description]
    for record in myresult:
        insertObject.append(dict(zip(columnNames, record)))
    cursor.close()
    return render_template('index.html', data=insertObject)

#Ruta para guardar usuarios en la bdd
@app.route('/user', methods=['POST'])
def addUser():
    #Cambiamos los nombres de los campos. Se repetirá en todas las funciones.
    nombre = request.form['nombre']
    asignatura = request.form['asignatura']
    nota = request.form['nota']

    if nombre and asignatura and nota:
        cursor = db.database.cursor()
        sql = "INSERT INTO gonzalez (nombre, asignatura, nota) VALUES (%s, %s, %s)"
        data = (nombre, asignatura, nota)
        cursor.execute(sql, data)
        db.database.commit()
    return redirect(url_for('home'))

@app.route('/delete/<string:id>')
def delete(id):
    cursor = db.database.cursor()
    sql = "DELETE FROM gonzalez WHERE id=%s"
    data = (id,)
    cursor.execute(sql, data)
    db.database.commit()
    return redirect(url_for('home'))

@app.route('/edit/<string:id>', methods=['POST'])
def edit(id):
    nombre = request.form['nombre']
    asignatura = request.form['asignatura']
    nota = request.form['nota']
    if nombre and asignatura and nota:
        cursor = db.database.cursor()
        sql = "UPDATE gonzalez SET nombre = %s, asignatura = %s, nota = %s WHERE id = %s"
        data = (nombre, asignatura, nota, id)
        cursor.execute(sql, data)
        db.database.commit()
    return redirect(url_for('home'))

#Funcion jugar.
@app.route('/jugar', methods=['POST'])
def jugar():
    cursor = db.database.cursor()
    cursor.execute("SELECT * FROM jugar")
    myresult = cursor.fetchall()
    insertObject = []
    columnNames = [column[0] for column in cursor.description]
    for record in myresult:
        insertObject.append(dict(zip(columnNames, record)))
    cursor.close()
    return render_template('form.html', data=insertObject)

@app.route('/comparar', methods=['POST'])
def comparar():
    num1 = request.form['num1']
    num2 = request.form['num2']
    if num1 and num2:
        cursor = db.database.cursor()
        if num1>num2:
            resp = 'El primer numero introducido es mayor.'
        elif num1 == num2:
            resp = "Los dos numeros introducidos son iguales."
        else:
            resp = 'El segundo numero introducido es mayor.'
        sql = "INSERT INTO jugar (num1, num2, resp) VALUES (%s, %s, %s)"
        data = (num1,num2,resp)
        cursor.execute(sql, data)
        db.database.commit()
    return redirect(url_for('jugar'))
#Cambiamos el puerto al pedido.
if __name__ == '__main__':
    app.run(debug=True, port=5500)